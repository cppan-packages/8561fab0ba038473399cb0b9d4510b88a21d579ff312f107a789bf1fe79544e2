#include "ace/config-all.h"



#if defined (ACE_COMPILE_TIMEPROBES)

#include "ace/Timeprobe.h"

#if !defined (__ACE_INLINE__)
#include "ace/Timeprobe.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_COMPILE_TIMEPROBES */
