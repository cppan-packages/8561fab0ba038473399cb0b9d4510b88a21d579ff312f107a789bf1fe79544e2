// -*- C++ -*-
#include "ace/OS_NS_wctype.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_wctype.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

